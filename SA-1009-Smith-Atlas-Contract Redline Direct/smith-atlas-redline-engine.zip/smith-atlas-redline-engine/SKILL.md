---
name: smith-atlas-redline-engine
description: Verified Smith-Atlas contract redline applier engine. Use for any Smith-Atlas contract review or redline: copy Engine_Redline_Applier.py from this folder instead of transcribing it.
---

# Smith-Atlas Redline Engine (delivery skill)

# Copyright 2026 Smith-Atlas LLC (SA-1009-V1).
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use these files 
# except in compliance with the License. You may obtain a copy of the License at http://
# www.apache.org/licenses/LICENSE-2.0.

This skill exists solely to place the verified applier engine on the code
environment's filesystem. It contains no process logic of its own — the
Smith-Atlas Contract Redline Direct system instructions govern the entire
review workflow.

When performing a Smith-Atlas contract redline (Phase 0 of the system
instructions):

1. Copy `Engine_Redline_Applier.py` from this skill's folder to the working
   directory instead of transcribing it from Knowledge.
2. Verify the copy against the `ENGINE_SHA256` checksum in the system
   instructions before running it, exactly as Phase 0 requires.
3. If the checksum does not match (stale skill version), discard this copy
   and fall back to the system instructions' normal acquisition protocol.

Do not use this skill for any other purpose.
