\---

name: smith-atlas-redline-engine
description: Verified Smith-Atlas contract redline applier engine. Use for any Smith-Atlas contract review or redline: copy Engine\_Redline\_Applier.py from this folder instead of transcribing it.
---

# Smith-Atlas Redline Engine (delivery skill)

# Copyright 2026 Smith-Atlas LLC (SA-1009-V1).

# Licensed under the MIT License (the "License"); you may not use these files

# except in compliance with the License. 

This skill exists solely to place the verified applier engine on the code
environment's filesystem. It contains no process logic of its own — the
Smith-Atlas Contract Redline Direct system instructions govern the entire
review workflow.

When performing a Smith-Atlas contract redline (Phase 0 of the system
instructions):

1. Copy `Engine\_Redline\_Applier.py` from this skill's folder to the working
directory instead of transcribing it from Knowledge.
2. Verify the copy against the `ENGINE\_SHA256` checksum in the system
instructions before running it, exactly as Phase 0 requires.
3. If the checksum does not match (stale skill version), discard this copy
and fall back to the system instructions' normal acquisition protocol.

Do not use this skill for any other purpose.

